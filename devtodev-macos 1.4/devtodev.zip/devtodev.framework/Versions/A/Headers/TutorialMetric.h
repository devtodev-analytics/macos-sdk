#import "ExtendedMetric.h"
#import "TutorialState.h"

extern NSString * const	DTD_STEP_KEY;

@interface TutorialMetric : ExtendedMetric

@property (nonatomic) NSInteger step;

- (id) initWithTutorialState: (NSInteger) state;

@end
