#import "AggregatedMetric.h"

@class CustomEventParams;
@class CustomEventRecord;

@interface CustomEvent : AggregatedMetric

@property (nonatomic) NSString * eventName;
@property (nonatomic) int maxId;
@property (nonatomic) NSMutableDictionary * events;

- (id) initWithName: (NSString *)name andParams: (CustomEventParams *)params withTimed: (BOOL)isTimed;

@end
