#import "Metric.h"
#import "TutorialState.h"

extern NSString * const	STEP_KEY;

@interface TutorialMetric : Metric

@property (nonatomic) NSInteger step;

- (id) initWithTutorialState: (NSInteger) state;

@end